<html><head><title>W3.CSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
        @media screen and (max-width:463px){.w3-sidebar{width:90px !important}#main{
                                                                                  margin-right:90px !important;
                                                                              }}
    </style>
</head><body class="w3-white">

<div class="w3-sidebar w3-bar-block w3-white w3-card" style="width:25%;right:0;">
    <h5 class="w3-bar-item">Menu</h5>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">Link 1</a>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">Link 2</a>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">Link 3</a>
</div>

<div id="main" style="margin-right:25%">

    <header class="w3-container w3-teal">
        <h3>My Page</h3>
    </header>

    <div class="w3-container">
        <p>Page content</p>
        <p>Right-side navigation.</p>
    </div>

</div>



</body></html>