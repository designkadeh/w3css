<html><head><title>W3.CSS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head><body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:50%">
    <div class="w3-container w3-dark-grey">
        <h4>Menu</h4>
    </div>

    <img src="/images/img_snowtops.jpg" alt="Snow" style="width:100%">
    <a class="w3-bar-item w3-button w3-red" href="#">Home</a>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">Projects
        <span class="w3-tag w3-red w3-round w3-margin-right w3-right">8</span></a>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">About</a>
    <a class="w3-bar-item w3-button" href="javascript:void(0)">Contact</a>

    <div class="w3-panel w3-blue-grey w3-display-container">
        <span onclick="this.parentElement.style.display='none'" class="w3-button w3-large w3-blue-grey w3-display-topright">×</span>
        <p>Lorem ipsum box...</p>
    </div>
</div>

<div style="margin-left:50%">

    <div class="w3-container">
        <h2>Page Content...</h2>
        <p>Add whatever you like inside the side navigation.</p>
    </div>

</div>



</body></html>